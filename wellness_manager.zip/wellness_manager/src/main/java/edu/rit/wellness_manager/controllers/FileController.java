package edu.rit.wellness_manager.controllers;

public interface FileController {
    final String foodFileName ="foods.csv";
    final String logFileName ="log.csv";
    final String exerciseFileName ="exercise.csv";
}
